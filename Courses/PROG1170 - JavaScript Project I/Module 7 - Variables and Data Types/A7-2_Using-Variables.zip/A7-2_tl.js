let loisDialogue = `Lois said, "I would love to have a juicy cheeseburger!"`,
supermanDialogue = `Superman replied, "Not now, Later! I am busy saving the world!"`;
document.write(loisDialogue);
document.write("<br><br>")
document.write(supermanDialogue);