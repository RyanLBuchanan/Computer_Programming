document.write("Get ready for some repeated text.<br>"); 
let count = 1;
while (count < 12) {
  document.write(count + ". I am part of the loop!<br>");
  count++;
}
document.write("Now we are back to the plain text.");