let computer = {
  speed: "4GHZ", 
  hd: "500GB", 
  ram: "8GB"
};

document.write("Computer Speed: " + computer.speed + "<br>");
document.write("Computer Hard Disk: " + computer.hd + "<br>");
document.write("Computer RAM: " + computer.ram);