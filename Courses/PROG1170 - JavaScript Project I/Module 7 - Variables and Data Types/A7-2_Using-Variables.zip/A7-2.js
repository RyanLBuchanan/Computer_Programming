let loisDialogue = '<p>Lois said, "I would love to have a juicy cheeseburger!"</p>',
supermanDialogue = '<p>Superman replied, "Not now, Later! I am busy saving the world!"</p>';
document.write(loisDialogue);
document.write(supermanDialogue);