document.write("Lois said, \"I would love to have a juicy cheeseburger!\"");
document.write("<br><br>");
document.write("Superman replied, \"Not now, Later! I am busy saving the world!\"");