let car = {
  seats: "cloth",
  engine: "V-6",
  show_features: function() {
    window.alert("car: " + car.seats + " seats, " + car.engine + " engine");
  }
};

car.show_features();